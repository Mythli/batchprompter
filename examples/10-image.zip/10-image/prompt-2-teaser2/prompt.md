**General Instructions:**
- Modify absolutely all subjects to have uniquely German facial features, hairstyles, and appearances, without relying on clothing to express this look.
- Do not add people who are not present in the original image.
- Preserve the original background and maintain the gender of all subjects.
- Leave all other elements strictly unchanged.
- Remove all text overlays which look like they have been digitally added in post-processing

**For the Focal Person:**
- Style the man in focus as a 33–40-year-old guy
- Change his identity completely while maintaining his exact pose.
- Adjust his gaze so he looks directly into the camera.
- Ensure his physique is athletic and fit.
- His clothing an appearance must fit right in {{industry}}.
- Remove any writing on his clothing
- Adjust his chest and shoulders specifically to be broad and defined.
- Ensure his muscular build appears natural and is not overly large.
- Make his face and posture radiate positive energy, confidence and authority which infects everyone around
