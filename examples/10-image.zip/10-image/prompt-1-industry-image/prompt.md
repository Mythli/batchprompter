{{real_scene_prompt}}
